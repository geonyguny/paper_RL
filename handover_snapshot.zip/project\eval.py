import os, csv, datetime
import numpy as _np
from typing import Callable, Tuple, Optional
from .env import RetirementEnv

# =========================
# Core episode & metrics
# =========================

def run_episode(env: RetirementEnv, actor: Callable, seed=0) -> Tuple[_np.ndarray, bool]:
    env.reset(seed=seed)
    W_hist = []
    early_hit = False
    for _ in range(env.T):
        state = env._state()
        q, w = actor(state)
        _, _, done, early = env.step(q, w)
        if early:
            early_hit = True
        W_hist.append(env.W)
        if done:
            break
    return _np.array(W_hist), early_hit


def metrics_wealth(WT_samples: _np.ndarray, alpha=0.95):
    EW = float(WT_samples.mean())
    q = _np.quantile(WT_samples, 1.0 - alpha)  # 5th pct of wealth
    tail = WT_samples[WT_samples <= q]
    ES_tail_mean = float(tail.mean()) if tail.size > 0 else float(q)
    return dict(EW=EW, ES95=ES_tail_mean)


def metrics_loss(WT_samples: _np.ndarray, F=1.0, alpha=0.95):
    # Loss = shortfall vs target F at terminal
    L = _np.maximum(F - WT_samples, 0.0)
    EL = float(L.mean())
    qL = _np.quantile(L, alpha)  # 95th pct of loss
    tail = L[L >= qL]
    ES = float(tail.mean()) if tail.size > 0 else float(qL)
    return dict(EW=float(WT_samples.mean()), EL=EL, ES95=ES)


def evaluate(cfg, actor, es_mode: str = "wealth"):
    env = RetirementEnv(cfg)
    WT = []
    early_flags = []
    for sd in cfg.seeds:
        for k in range(cfg.n_paths_eval):
            W_hist, early = run_episode(env, actor, seed=sd * 100000 + k)
            WT.append(W_hist[-1] if W_hist.size > 0 else 0.0)
            early_flags.append(early)
    WT = _np.array(WT)

    ruin_rate = float(_np.mean(early_flags))
    if es_mode == "loss":
        F = cfg.F_target if getattr(cfg, "F_target", 0.0) > 0 else 1.0
        m = metrics_loss(WT, F=F, alpha=cfg.alpha)
        m["Ruin"] = ruin_rate
        m["mean_WT"] = float(WT.mean())
        return m
    else:
        m = metrics_wealth(WT, alpha=cfg.alpha)
        m["Ruin"] = ruin_rate
        m["mean_WT"] = m["EW"]
        return m


# =========================
# PR-3: Autosave Hook
# =========================

def _ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def _now_iso() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def save_metrics_autocsv(metrics: dict, cfg, outputs: Optional[str] = None) -> str:
    """
    Append one row of metrics & config into outputs/_logs/metrics.csv
    Fields kept compact for gate checks and quick frontiers.
    """
    out_dir = outputs or getattr(cfg, "outputs", "./outputs")
    logs_dir = os.path.join(out_dir, "_logs")
    _ensure_dir(logs_dir)
    csv_path = os.path.join(logs_dir, "metrics.csv")

    # pull optional attrs safely
    method = getattr(cfg, "method", None)
    es_mode = getattr(cfg, "es_mode", None)
    hedge_on = getattr(cfg, "hedge_on", False)
    hedge_mode = getattr(cfg, "hedge_mode", None)

    # canonical header (stable order)
    header = [
        "ts", "asset", "method", "es_mode",
        "alpha", "lambda_term", "F_target",
        "EW", "ES95", "EL", "Ruin", "mean_WT",
        "fee_annual", "w_max", "floor_on", "f_min_real",
        "hedge_on", "hedge_mode",
        "horizon_years", "steps_per_year",
        "seeds", "n_paths_eval", "tag",
    ]

    row = {
        "ts": _now_iso(),
        "asset": getattr(cfg, "asset", None),
        "method": method,
        "es_mode": es_mode,
        "alpha": getattr(cfg, "alpha", None),
        "lambda_term": getattr(cfg, "lambda_term", None),
        "F_target": getattr(cfg, "F_target", None),
        "EW": metrics.get("EW"),
        "ES95": metrics.get("ES95"),
        "EL": metrics.get("EL"),
        "Ruin": metrics.get("Ruin"),
        "mean_WT": metrics.get("mean_WT"),
        "fee_annual": getattr(cfg, "phi_adval", None),
        "w_max": getattr(cfg, "w_max", None),
        "floor_on": getattr(cfg, "floor_on", None),
        "f_min_real": getattr(cfg, "f_min_real", None),
        "hedge_on": bool(hedge_on),
        "hedge_mode": hedge_mode,
        "horizon_years": getattr(cfg, "horizon_years", None),
        "steps_per_year": getattr(cfg, "steps_per_year", None),
        "seeds": ",".join(str(s) for s in getattr(cfg, "seeds", ())) if getattr(cfg, "seeds", None) else None,
        "n_paths_eval": getattr(cfg, "n_paths_eval", None),
        "tag": getattr(cfg, "tag", None),
    }

    write_header = not os.path.exists(csv_path) or os.path.getsize(csv_path) == 0
    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=header)
        if write_header:
            w.writeheader()
        w.writerow(row)

    return csv_path


# =========================
# (Optional) Frontiers
# =========================

def plot_frontier_from_csv(csv_path: str, out_path: Optional[str] = None) -> Optional[str]:
    """
    Try to draw EW–ES95 frontier from metrics.csv.
    - If matplotlib unavailable, silently skip and return None.
    - Saves to out_path (or alongside csv_path as frontier_EW_ES.png)
    """
    try:
        import csv as _csv
        import matplotlib.pyplot as plt  # optional dependency

        xs, ys = [], []
        with open(csv_path, "r", encoding="utf-8") as f:
            r = _csv.DictReader(f)
            for row in r:
                try:
                    ew = float(row.get("EW", "nan"))
                    es = float(row.get("ES95", "nan"))
                    if _np.isfinite(ew) and _np.isfinite(es):
                        xs.append(ew); ys.append(es)
                except Exception:
                    continue

        if not xs:
            return None

        plt.figure()
        plt.scatter(xs, ys, s=16)
        plt.xlabel("EW (Expected Terminal Wealth)")
        plt.ylabel("ES95")
        plt.title("EW–ES95 frontier (from metrics.csv)")

        if out_path is None:
            base = os.path.dirname(csv_path)
            out_path = os.path.join(base, "frontier_EW_ES.png")
        plt.savefig(out_path, bbox_inches="tight")
        plt.close()
        return out_path
    except Exception:
        return None
