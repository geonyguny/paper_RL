
import numpy as _np
from .env import RetirementEnv
from .config import SimConfig

def rule_4pct(env: RetirementEnv, cfg: SimConfig):
    q_m = 1.0 - (1.0 - 0.04)**(1.0/cfg.steps_per_year)
    w = cfg.w_fixed if cfg.w_fixed is not None else cfg.w_max
    W_hist = []
    for _ in range(env.T):
        _, _, done = env.step(q=q_m, w=w)
        W_hist.append(env.W)
        if done: break
    return _np.array(W_hist)

def rule_cpb(env: RetirementEnv, cfg: SimConfig):
    q_m = cfg.monthly()['p_m']
    w = cfg.w_fixed if cfg.w_fixed is not None else cfg.w_max
    W_hist = []
    for _ in range(env.T):
        _, _, done = env.step(q=q_m, w=w)
        W_hist.append(env.W)
        if done: break
    return _np.array(W_hist)

def rule_vpw(env: RetirementEnv, cfg: SimConfig):
    m = cfg.monthly(); g = m['g_m']
    W_hist = []
    for _ in range(env.T):
        Nm = env.T - env.t
        a = (1.0 - (1.0 + g)**(-Nm))/g if g > 0 else max(Nm, 1)
        q_m = 1.0 / a
        w = cfg.w_fixed if cfg.w_fixed is not None else cfg.w_max
        _, _, done = env.step(q=q_m, w=w)
        W_hist.append(env.W)
        if done: break
    return _np.array(W_hist)
