import numpy as _np
from typing import Optional, Tuple, Dict
from .config import SimConfig
from .market import IIDNormalMarket

class RetirementEnv:
    """
    Retirement decumulation environment.

    Update order (Spec 7.6):
      1) clipping (constraints)
      2) consumption: c_t = q_t * W_t
      3) returns: W_net * [1 + w_t*R_risk + (1-w_t)*R_safe]
      4) fee: - phi_m * W_t   (ad-valorem on beginning-of-step wealth)

    Notes:
      - Floor(level) 적용 시 q_min = min(1, f_min_real / W_t)
      - w ∈ [0, w_max] (no short/leverage per core spec)
      - Risky path is pre-sampled i.i.d. normal via IIDNormalMarket
      - Hedge(MVP):
          * mode="mu": per-period μ haircut (R_t ← R_t - cost_m)
          * mode="sigma": per-period σ reduction (R_t ← μ_m + (1-k)·(R_t - μ_m))
    """

    def __init__(self, cfg: SimConfig):
        self.cfg = cfg
        self.m = cfg.monthly()  # {'mu_m','sigma_m','rf_m','phi_m','p_m','g_m','beta_m'}
        self.market = IIDNormalMarket(cfg)
        self.T = cfg.horizon_years * cfg.steps_per_year

        # --- Hedge params (monthly) ---
        self._hedge_on: bool = bool(getattr(cfg, "hedge_on", False))
        self._hedge_mode: str = str(getattr(cfg, "hedge_mode", "mu"))
        # annual -> monthly for cost (consistent with mu conversion)
        hedge_cost_annual = float(getattr(cfg, "hedge_cost", 0.0) or 0.0)
        steps = max(int(cfg.steps_per_year), 1)
        self._hedge_cost_m: float = (1.0 + hedge_cost_annual) ** (1.0 / steps) - 1.0
        # clamp k to [0,1]
        k = float(getattr(cfg, "hedge_sigma_k", 0.0) or 0.0)
        self._hedge_sigma_k: float = float(min(max(k, 0.0), 1.0))

        # cache μ_m for sigma-mode transform
        self._mu_m: float = float(self.m["mu_m"])

        self.reset()

    # --- internal: apply hedge transform to risky return path ---
    def _apply_hedge(self, r_path: _np.ndarray) -> _np.ndarray:
        if not self._hedge_on:
            return r_path
        if self._hedge_mode == "mu":
            # μ haircut: subtract monthly cost from every draw
            return r_path - self._hedge_cost_m
        else:
            # σ reduction: shrink deviations from the model monthly mean (μ_m)
            # R_adj = μ_m + (1-k) * (R - μ_m)
            return self._mu_m + (1.0 - self._hedge_sigma_k) * (r_path - self._mu_m)

    def reset(self, seed: Optional[int] = None, W0: float = 1.0) -> Dict:
        if seed is not None:
            self.market.seed(seed)
        self.t = 0
        self.W = float(W0)
        self.W0 = float(W0)
        self.peakW = float(W0)
        # Pre-sample risky returns for the full horizon (iid normal)
        base_path = self.market.sample_risky(self.T)
        # Apply hedge transform if enabled
        self.path_risky = self._apply_hedge(_np.asarray(base_path, dtype=float))
        return self._state()

    def _state(self) -> Dict:
        return dict(t=self.t, W=self.W, W0=self.W0, peakW=self.peakW)

    def step(self, q: float, w: float) -> Tuple[Dict, float, bool, bool]:
        # --- 1) clipping / constraints ---
        # risky weight: [0, w_max]
        w = float(_np.clip(float(w), 0.0, self.cfg.w_max))
        # consumption rate: [0, 1]
        q = float(_np.clip(float(q), 0.0, 1.0))

        # level floor (if on): enforce q >= q_min = min(1, f_min_real / W_t)
        if self.cfg.floor_on and self.cfg.f_min_real > 0.0 and self.W > 0.0:
            q_min = min(1.0, self.cfg.f_min_real / self.W)
            q = max(q, q_min)

        # --- 2) consumption ---
        c_t = q * self.W
        W_net = self.W - c_t

        # --- 3) returns (risky + safe mix) ---
        R_risk = float(self.path_risky[self.t])  # per-period risky return (hedged if enabled)
        R_safe = float(self.m["rf_m"])           # per-period safe return
        gross = 1.0 + (w * R_risk) + ((1.0 - w) * R_safe)
        W_next = W_net * gross

        # --- 4) fee (ad-valorem on beginning-of-step wealth W_t) ---
        W_next = W_next - float(self.m["phi_m"]) * self.W

        # --- clip / bookkeeping ---
        # (선택) 상한 클립으로 수치적 안정성 보강
        if hasattr(self.cfg, "hjb_W_max"):
            W_next = float(_np.clip(W_next, 0.0, self.cfg.hjb_W_max))
        else:
            W_next = float(max(W_next, 0.0))

        self.t += 1
        early_ruin = bool(W_next <= 0.0 and self.t < self.T)

        self.W = W_next
        self.peakW = max(self.peakW, self.W)

        done = bool(self.t >= self.T or self.W <= 0.0)
        return self._state(), c_t, done, early_ruin
