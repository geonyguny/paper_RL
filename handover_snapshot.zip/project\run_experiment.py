import argparse, json, os, hashlib, sys, csv, datetime
import numpy as _np
from .config import (
    SimConfig, ASSET_PRESETS,
    CVAR_TARGET_DEFAULT, CVAR_TOL_DEFAULT, LAMBDA_MIN_DEFAULT, LAMBDA_MAX_DEFAULT, LAMBDA_MAX_ITER
)
from .env import RetirementEnv
from .hjb import HJBSolver
from .rl import A2CTrainer
from .eval import evaluate

# (optional) autosave 유틸이 eval.py에 붙어있다면 사용
try:
    from .eval import save_metrics_autocsv, plot_frontier_from_csv  # noqa
    _HAS_AUTOSAVE = True
except Exception:
    _HAS_AUTOSAVE = False

# --- PR-4: stdout UTF-8 안전화 ---
try:
    sys.stdout.reconfigure(encoding='utf-8')  # py3.7+
except Exception:
    pass


def _arrhash(a):
    if a is None:
        return "none"
    x = _np.asarray(a, dtype=_np.float32).tobytes()
    return hashlib.md5(x).hexdigest()


def _auto_eta_grid(cfg: SimConfig, requested_n: int = None):
    """
    F_target에 맞춰 η-grid 자동 생성:
      - lambda_term <= 0: η-grid은 (0.0,)로 축소
      - lambda_term > 0: η-grid = linspace(0, F_target>0 ? F_target : 1.0, n)
    """
    cur = getattr(cfg, "hjb_eta_grid", ())
    if cfg.lambda_term <= 0.0:
        if not cur or len(cur) <= 1:
            cfg.hjb_eta_grid = (0.0,)
        return

    n = int(requested_n or getattr(cfg, "hjb_eta_n", 41) or 41)
    F = float(cfg.F_target if (getattr(cfg, "F_target", 0.0) or 0.0) > 0.0 else 1.0)
    try:
        cfg.hjb_eta_grid = tuple(_np.linspace(0.0, F, n))
    except Exception:
        step = F / max(n - 1, 1)
        cfg.hjb_eta_grid = tuple(0.0 + i * step for i in range(n))


def make_cfg(args) -> SimConfig:
    cfg = SimConfig()
    if args.asset in ASSET_PRESETS:
        for k, v in ASSET_PRESETS[args.asset].items():  # type: ignore  # (safety)
            setattr(cfg, k, v)
    cfg.asset = args.asset

    # overrides (핵심 파라미터)
    for k, v in dict(
        w_max=args.w_max,
        phi_adval=args.fee_annual,
        horizon_years=args.horizon_years,
        lambda_term=args.lambda_term,
        alpha=args.alpha,
        baseline=args.baseline,
        p_annual=args.p_annual,
        g_real_annual=args.g_real_annual,
        w_fixed=args.w_fixed,
        floor_on=args.floor_on,
        f_min_real=args.f_min_real,
        F_target=args.F_target,
        hjb_W_grid=args.hjb_W_grid,
        hjb_Nshock=args.hjb_Nshock,
        # hedge
        hedge_on=(args.hedge == "on"),
        hedge_mode=args.hedge_mode,
        hedge_cost=args.hedge_cost,
        hedge_sigma_k=args.hedge_sigma_k,
        # hjb_eta_n은 아래 _auto_eta_grid에서 사용
    ).items():
        if v is not None:
            setattr(cfg, k, v)

    cfg.seeds = tuple(args.seeds)
    cfg.n_paths_eval = int(args.n_paths)
    cfg.outputs = args.outputs
    cfg.method = args.method
    cfg.es_mode = args.es_mode

    # ==== 해상도/plateau 완화 핫픽스 ====
    # 1) η-grid 자동화: F_target 연동
    _auto_eta_grid(cfg, requested_n=args.hjb_eta_n)

    # 2) w-action 격자: config.py 자동설정 보완(8점 균등)
    if hasattr(cfg, "hjb_w_grid") and (getattr(cfg, "hjb_w_grid", None) in (None, ())):
        n_w = 8
        cfg.hjb_w_grid = tuple(_np.round(_np.linspace(0.0, cfg.w_max, n_w), 2))

    # 3) dev split OFF + 샘플수 하한(plateau 방지)
    setattr(cfg, "dev_split_w_grid", False)
    setattr(cfg, "hjb_Nshock", max(int(getattr(cfg, "hjb_Nshock", 32)), 256))

    return cfg


def build_actor(cfg: SimConfig, args):
    env = RetirementEnv(cfg)
    if args.method == "rule":
        if cfg.baseline == "4pct":
            def actor(s):
                q_m = 1.0 - (1.0 - 0.04)**(1.0/cfg.steps_per_year)
                w = cfg.w_fixed if cfg.w_fixed is not None else cfg.w_max
                return q_m, w
            return actor
        elif cfg.baseline == "cpb":
            def actor(s):
                q_m = cfg.monthly()['p_m']
                w = cfg.w_fixed if cfg.w_fixed is not None else cfg.w_max
                return q_m, w
            return actor
        elif cfg.baseline == "vpw":
            def actor(s):
                m = cfg.monthly(); g = m['g_m']; Nm = env.T - s['t']
                a = (1.0 - (1.0+g)**(-Nm))/g if g > 0 else max(Nm, 1)
                q_m = min(1.0, 1.0 / a)
                w = cfg.w_fixed if cfg.w_fixed is not None else cfg.w_max
                return q_m, w
            return actor
        else:
            raise SystemExit("--baseline required for method=rule (4pct|cpb|vpw)")
    elif args.method == "hjb":
        # ==== HJB 정책 생성 ====
        sol = HJBSolver(cfg).solve(seed=cfg.seeds[0])
        Pi_w = sol.get('Pi_w', None)
        Pi_q = sol.get('Pi_q', None)

        # 정책 해시(지문 확인) + eta 출력
        print("policy_hash_q=", _arrhash(Pi_q))
        print("policy_hash_w=", _arrhash(Pi_w))
        if 'eta' in sol:
            try:
                print("eta_selected=", float(sol['eta']))
            except Exception:
                pass

        # ==== 디버그: 정책 사용값 통계/유니크(초기 시점) ====
        try:
            if Pi_w is not None and Pi_q is not None and getattr(Pi_w, "size", 0) > 0 and getattr(Pi_q, "size", 0) > 0:
                print("w_stats[min,mean,max]=", [float(_np.min(Pi_w)), float(_np.mean(Pi_w)), float(_np.max(Pi_w))])
                print("q_stats[min,mean,max]=", [float(_np.min(Pi_q)), float(_np.mean(Pi_q)), float(_np.max(Pi_q))])
                print("unique_w_t0≈", _np.unique(Pi_w[0, :])[:10])
                print("unique_q_t0≈", _np.unique(Pi_q[0, :])[:10])
        except Exception as _e:
            print(f"[dbg] policy stats skipped: {_e}")

        # W-grid (solver 제공 시 우선)
        if 'W_grid' in sol and sol['W_grid'] is not None:
            Wg = _np.asarray(sol['W_grid'], dtype=float)
        else:
            Wg = _np.linspace(cfg.hjb_W_min, cfg.hjb_W_max, cfg.hjb_W_grid)

        if Pi_w is None or getattr(Pi_w, 'size', 0) == 0 or Pi_q is None or getattr(Pi_q, 'size', 0) == 0:
            # fallback: 상수 정책
            const_w = float(min(max(cfg.hjb_w_grid[-1], 0.0), cfg.w_max))
            q4 = 1.0 - (1.0 - 0.04)**(1.0/cfg.steps_per_year)
            const_q = float(q4)
            def actor(s): return const_q, const_w
            return actor

        T_pol = int(Pi_w.shape[0])
        def actor(s):
            t_idx = int(_np.clip(s['t'], 0, T_pol - 1))
            i = int(_np.clip(_np.searchsorted(Wg, s['W']) - 1, 0, Wg.size - 2))
            w = float(Pi_w[t_idx, i]); q = float(Pi_q[t_idx, i])
            return q, w
        return actor
    else:
        pol = A2CTrainer(cfg).train(seed=cfg.seeds[0])
        def actor(s): return pol.act(s)
        return actor


# --- 공통 유틸 ---
def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def now_iso() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def slim_args(args) -> dict:
    keys = [
        "asset", "method", "baseline", "w_max", "fee_annual", "horizon_years",
        "alpha", "lambda_term", "F_target", "p_annual", "g_real_annual",
        "w_fixed", "floor_on", "f_min_real", "es_mode", "outputs",
        "hjb_W_grid", "hjb_Nshock", "hjb_eta_n",
        # hedge
        "hedge", "hedge_mode", "hedge_cost", "hedge_sigma_k",
        # calib
        "cvar_target", "cvar_tol", "lambda_min", "lambda_max",
        "calib_fast", "calib_max_iter",
        # eval
        "seeds", "n_paths",
    ]
    d = {}
    for k in keys:
        v = getattr(args, k, None)
        d[k] = v
    return d


def append_metrics_csv(path: str, payload: dict):
    """PR-3 fallback: eval.save_metrics_autocsv가 없을 때 최소 CSV 기록."""
    row = {
        'ts': now_iso(),
        'asset': payload.get('asset'),
        'method': payload.get('method'),
        'lambda': payload.get('lambda_term'),
        'F_target': payload.get('F_target'),
        'alpha': payload.get('alpha'),
        'ES95': (payload.get('metrics') or {}).get('ES95'),
        'EW': (payload.get('metrics') or {}).get('EW'),
        'Ruin': (payload.get('metrics') or {}).get('Ruin'),
        'mean_WT': (payload.get('metrics') or {}).get('mean_WT'),
        'hedge_on': (payload.get('args') or {}).get('hedge') == 'on',
        'hedge_mode': (payload.get('args') or {}).get('hedge_mode'),
        'fee_annual': payload.get('fee_annual'),
        'w_max': payload.get('w_max'),
        'horizon_years': payload.get('horizon_years'),
        'seeds': (payload.get('args') or {}).get('seeds'),
        'n_paths': (payload.get('args') or {}).get('n_paths'),
    }
    write_header = not os.path.exists(path)
    with open(path, 'a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            w.writeheader()
        w.writerow(row)


# --- 단일 실행 (공통) ---
def run_once(args):
    cfg = make_cfg(args)
    ensure_dir(args.outputs)
    actor = build_actor(cfg, args)
    m = evaluate(cfg, actor, es_mode=args.es_mode)
    out = dict(
        asset=cfg.asset, method=args.method, baseline=cfg.baseline, metrics=m,
        w_max=cfg.w_max, fee_annual=cfg.phi_adval, lambda_term=cfg.lambda_term,
        alpha=cfg.alpha, F_target=cfg.F_target, es_mode=args.es_mode,
        n_paths=cfg.n_paths_eval * len(cfg.seeds),
        args=slim_args(args),
    )
    # PR-3 autosave: on일 때만 저장
    if args.autosave == "on":
        try:
            if _HAS_AUTOSAVE:
                csv_path = save_metrics_autocsv(m, cfg, outputs=cfg.outputs)
                print(f"[autosave] metrics -> {csv_path}")
            else:
                ensure_dir(os.path.join(cfg.outputs, "_logs"))
                csv_path = os.path.join(cfg.outputs, "_logs", "metrics.csv")
                append_metrics_csv(csv_path, out)
                print(f"[autosave:fallback] metrics -> {csv_path}")
        except Exception as e:
            print(f"[autosave] skipped: {e}")
    return out


# --- PR-1: CVaR λ calibration (fast mode + early stop + final high-res) ---
def copy_args(args, **overrides):
    from argparse import Namespace
    d = vars(args).copy()
    d.update(overrides)
    return Namespace(**d)


def calibrate_lambda(args):
    """Binary search on lambda_term to hit ES95(loss) <= cvar_target within cvar_tol."""
    lo, hi = float(args.lambda_min), float(args.lambda_max)
    target = float(args.cvar_target)
    tol = float(args.cvar_tol)
    max_iter = int(getattr(args, "calib_max_iter", 8))
    use_fast = (getattr(args, "calib_fast", "on") == "on")

    history = []
    cache = {}

    def eval_at(lmbd, fast=True):
        if (lmbd, fast) in cache:
            return cache[(lmbd, fast)]
        overrides = dict(lambda_term=float(lmbd), es_mode="loss")
        if fast and use_fast:
            # 저해상도 + 적은 paths + 단일 seed
            overrides.update(dict(
                hjb_W_grid=81, hjb_Nshock=128, hjb_eta_n=41,
                n_paths=150, seeds=[args.seeds[0]]
            ))
        local = copy_args(args, **overrides)
        res = run_once(local)
        es = (res.get('metrics') or {}).get('ES95')
        cache[(lmbd, fast)] = (res, es)
        return cache[(lmbd, fast)]

    # 초기 브래킷 평가(FAST)
    res_lo, es_lo = eval_at(lo, fast=True)
    res_hi, es_hi = eval_at(hi, fast=True)

    # 둘 다 이미 target 이하이면 즉시 반환(불필요 확장 방지)
    if (es_lo is not None) and (es_hi is not None) and (es_lo <= target) and (es_hi <= target):
        # 최종 고해상도 1회 재평가(λ=lo)
        final_res, final_es = eval_at(lo, fast=False)
        final_res['cvar_calibration'] = {
            'selected_lambda': float(lo),
            'selected_ES95': float(final_es) if final_es is not None else None,
            'cvar_target': target,
            'cvar_tol': tol,
            'lambda_min': float(args.lambda_min),
            'lambda_max': float(args.lambda_max),
            'iterations': 1,
            'status': 'already_below_target',
            'history_tail': [{'lambda': float(lo), 'ES95': float(es_lo)}],
        }
        return final_res

    # 필요 시 hi 확장(FAST)
    expand = 0
    while (es_lo is not None) and (es_hi is not None) and (es_lo > target) and (es_hi > target) and expand < 3:
        hi *= 2.0
        res_hi, es_hi = eval_at(hi, fast=True)
        expand += 1

    best = (lo, res_lo, es_lo)
    prev_es = None

    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        res_mid, es_mid = eval_at(mid, fast=True)
        history.append({'lambda': float(mid), 'ES95': float(es_mid) if es_mid is not None else None})

        # plateau 감지: ES 변화량이 매우 작으면 중단
        if prev_es is not None and es_mid is not None and abs(es_mid - prev_es) < 1e-4:
            best = (mid, res_mid, es_mid)
            status = 'plateau'
            break
        prev_es = es_mid

        if es_mid is None:
            lo = mid  # 정보 부족 시 penalty 증가 방향으로 이동
            best = (mid, res_mid, es_mid)
            status = 'incomplete'
            continue

        if abs(es_mid - target) <= tol:
            best = (mid, res_mid, es_mid)
            status = 'ok'
            break

        if es_mid > target:
            # tail risk 초과 → penalty↑ 필요
            lo = mid
        else:
            hi = mid
        best = (mid, res_mid, es_mid)
        status = 'ok'

    chosen_lambda, _, _ = best

    # 최종 1회 고해상도 재평가
    final_res, final_es = eval_at(chosen_lambda, fast=False)
    final_res['cvar_calibration'] = {
        'selected_lambda': float(chosen_lambda),
        'selected_ES95': float(final_es) if final_es is not None else None,
        'cvar_target': target,
        'cvar_tol': tol,
        'lambda_min': float(args.lambda_min),
        'lambda_max': float(args.lambda_max),
        'iterations': len(history),
        'status': status if 'status' in locals() else 'ok',
        'history_tail': history[-5:],  # 최근 5회만
    }
    return final_res


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--asset", type=str, default="KR")
    p.add_argument("--method", type=str, default="hjb", choices=["hjb", "rl", "rule"])
    p.add_argument("--baseline", type=str, default=None)
    p.add_argument("--w_max", type=float, default=0.70)
    p.add_argument("--fee_annual", type=float, default=0.004)
    p.add_argument("--horizon_years", type=int, default=35)
    p.add_argument("--alpha", type=float, default=0.95)
    p.add_argument("--lambda_term", type=float, default=0.0)
    p.add_argument("--F_target", type=float, default=0.0)
    p.add_argument("--p_annual", type=float, default=0.04)
    p.add_argument("--g_real_annual", type=float, default=0.02)
    p.add_argument("--w_fixed", type=float, default=0.60)
    p.add_argument("--floor_on", action="store_true")
    p.add_argument("--f_min_real", type=float, default=0.0)
    p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    p.add_argument("--n_paths", type=int, default=100)
    p.add_argument("--es_mode", type=str, default="wealth", choices=["wealth", "loss"])
    p.add_argument("--outputs", type=str, default="./outputs")
    # === 해상도/튜닝 CLI(선택) ===
    p.add_argument("--hjb_W_grid", type=int, default=None)
    p.add_argument("--hjb_Nshock", type=int, default=None)
    p.add_argument("--hjb_eta_n", type=int, default=None)
    # === PR-2: Hedge ===
    p.add_argument("--hedge", choices=["on", "off"], default="off")
    p.add_argument("--hedge_mode", choices=["mu", "sigma"], default="mu")
    p.add_argument("--hedge_cost", type=float, default=0.005)
    p.add_argument("--hedge_sigma_k", type=float, default=0.20)
    # === PR-1: CVaR calibration ===
    p.add_argument("--cvar_target", type=float, default=CVAR_TARGET_DEFAULT)
    p.add_argument("--cvar_tol", type=float, default=CVAR_TOL_DEFAULT)
    p.add_argument("--lambda_min", type=float, default=LAMBDA_MIN_DEFAULT)
    p.add_argument("--lambda_max", type=float, default=LAMBDA_MAX_DEFAULT)
    # 영구 패치 옵션
    p.add_argument("--calib_fast", choices=["on", "off"], default="on")
    p.add_argument("--calib_max_iter", type=int, default=8)
    # === PR-3: autosave toggle ===
    p.add_argument("--autosave", choices=["on", "off"], default="off")

    args = p.parse_args()

    # CVaR calibration 래퍼 (HJB만 대상)
    if args.method == "hjb" and (args.cvar_target is not None):
        out = calibrate_lambda(args)
    else:
        out = run_once(args)

    # 최종 출력
    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
