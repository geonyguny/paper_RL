
import numpy as _np
from .config import SimConfig

class IIDNormalMarket:
    def __init__(self, cfg: SimConfig):
        m = cfg.monthly()
        self.mu = m['mu_m']
        self.sigma = m['sigma_m']
        self.rf = m['rf_m']
        self.steps_per_year = cfg.steps_per_year
        self.rng = _np.random.default_rng(0)

    def seed(self, s: int):
        self.rng = _np.random.default_rng(s)

    def sample_risky(self, T: int) -> _np.ndarray:
        return self.rng.normal(loc=self.mu, scale=self.sigma, size=T)